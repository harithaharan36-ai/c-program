I am creating a pull request for...

- [ ] New algorithm
- [ ] Update to an algorithm
- [ ] Fix an error
- [ ] Other - *Describe below*